import React from 'react';
import Farmer from './pages/Farmer';
import Lab from './pages/Lab';
import Processor from './pages/Processor';
import Manufacturer from './pages/Manufacturer';
import Consumer from './pages/Consumer';

export default function App(){
  const [page, setPage] = React.useState('farmer');
  return (
    <div style={{ padding: 20 }}>
      <h2>Botanical Traceability POC</h2>
      <nav style={{ marginBottom: 12 }}>
        <button onClick={()=>setPage('farmer')}>Farmer</button>
        <button onClick={()=>setPage('lab')}>Lab</button>
        <button onClick={()=>setPage('processor')}>Processor</button>
        <button onClick={()=>setPage('manufacturer')}>Manufacturer</button>
        <button onClick={()=>setPage('consumer')}>Consumer</button>
      </nav>
      {page==='farmer' && <Farmer />}
      {page==='lab' && <Lab />}
      {page==='processor' && <Processor />}
      {page==='manufacturer' && <Manufacturer />}
      {page==='consumer' && <Consumer />}
    </div>
  );
}
