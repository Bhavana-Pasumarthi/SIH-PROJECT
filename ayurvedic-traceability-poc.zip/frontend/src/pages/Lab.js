import React from 'react';
import API from '../api';

export default function Lab(){
  const [batchId,setBatchId]=React.useState('');
  const [testType,setTestType]=React.useState('Pesticide');
  const [result,setResult]=React.useState('Pass');
  const [msg,setMsg]=React.useState('');

  const submit=async()=>{
    try{
      const res = await API.post('/quality',{ batchId, labId: 'LAB001', testType, result });
      setMsg('Quality recorded');
    }catch(e){ setMsg('Error'); }
  }

  return (
    <div>
      <h3>Lab - Upload Test</h3>
      <div>Batch ID: <input value={batchId} onChange={e=>setBatchId(e.target.value)} /></div>
      <div>Test Type: <input value={testType} onChange={e=>setTestType(e.target.value)} /></div>
      <div>Result: <input value={result} onChange={e=>setResult(e.target.value)} /></div>
      <button onClick={submit}>Submit Test</button>
      <div>{msg}</div>
    </div>
  );
}
