import React from 'react';
import API from '../api';

export default function Consumer(){
  const [batchId,setBatchId]=React.useState('');
  const [prov,setProv]=React.useState(null);

  const fetchProv=async()=>{
    const res = await API.get(`/provenance/${batchId}`);
    setProv(res.data);
  }

  return (
    <div>
      <h3>Consumer - View Provenance</h3>
      <div>Batch ID (from QR): <input value={batchId} onChange={e=>setBatchId(e.target.value)} /></div>
      <button onClick={fetchProv}>Fetch Provenance</button>
      <pre>{prov && JSON.stringify(prov, null, 2)}</pre>
    </div>
  );
}
