import React from 'react';
import API from '../api';

export default function Farmer(){
  const [species, setSpecies] = React.useState('Ashwagandha');
  const [batchId, setBatchId] = React.useState('');
  const [lat, setLat] = React.useState('');
  const [lng, setLng] = React.useState('');
  const [msg, setMsg] = React.useState('');

  const submit = async () => {
    try{
      const res = await API.post('/collection', { species, location: { lat, lng }, collectorId: 'FARMER001' });
      setBatchId(res.data.batchId);
      setMsg('Collection recorded, batchId=' + res.data.batchId);
    }catch(e){ setMsg('Error:'+e.message); }
  }

  return (
    <div>
      <h3>Farmer - Record Collection</h3>
      <div>
        Species: <input value={species} onChange={e=>setSpecies(e.target.value)} />
      </div>
      <div>
        Latitude: <input value={lat} onChange={e=>setLat(e.target.value)} />
        Longitude: <input value={lng} onChange={e=>setLng(e.target.value)} />
      </div>
      <button onClick={submit}>Submit Collection</button>
      <div>{msg}</div>
      <div>Batch ID: {batchId}</div>
    </div>
  );
}
