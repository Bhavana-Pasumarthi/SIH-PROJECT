import React from 'react';
import API from '../api';

export default function Manufacturer(){
  const [batchId,setBatchId]=React.useState('');
  const [qrDataUrl,setQrDataUrl]=React.useState(null);

  const genQR=async()=>{
    const res = await API.post('/generate-qr',{ batchId });
    setQrDataUrl(res.data.dataUrl);
  }

  return (
    <div>
      <h3>Manufacturer - Generate QR</h3>
      <div>Batch ID: <input value={batchId} onChange={e=>setBatchId(e.target.value)} /></div>
      <button onClick={genQR}>Generate QR</button>
      {qrDataUrl && (<div>
        <h4>QR Code (Scan to view batch)</h4>
        <img src={qrDataUrl} alt="qr" />
      </div>)}
    </div>
  );
}
