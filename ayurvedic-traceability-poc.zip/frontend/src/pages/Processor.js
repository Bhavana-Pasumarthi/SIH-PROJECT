import React from 'react';
import API from '../api';

export default function Processor(){
  const [batchId,setBatchId]=React.useState('');
  const [step,setStep]=React.useState('Drying');
  const [conditions,setConditions]=React.useState('Temp=35C');
  const [msg,setMsg]=React.useState('');

  const submit=async()=>{
    try{
      const res = await API.post('/processing',{ batchId, processorId: 'PROC001', step, conditions });
      setMsg('Processing step recorded');
    }catch(e){ setMsg('Error'); }
  }

  return (
    <div>
      <h3>Processor - Add Step</h3>
      <div>Batch ID: <input value={batchId} onChange={e=>setBatchId(e.target.value)} /></div>
      <div>Step: <input value={step} onChange={e=>setStep(e.target.value)} /></div>
      <div>Conditions: <input value={conditions} onChange={e=>setConditions(e.target.value)} /></div>
      <button onClick={submit}>Submit Step</button>
      <div>{msg}</div>
    </div>
  );
}
